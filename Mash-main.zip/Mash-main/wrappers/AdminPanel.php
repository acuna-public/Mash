<?php
	
	namespace Mash;
	
	require 'WebSite.php';
	
	abstract class AdminPanel extends WebSite {
		
	}