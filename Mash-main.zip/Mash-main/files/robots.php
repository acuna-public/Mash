<?php
	
	$this->robots = [
		
		'antabot' => 'antabot (private)',
		
		'aport' => 'Aport',
		'Ask Jeeves' => 'Ask Jeeves',
		'Asterias' =>	'Singingfish Spider',
		'Baiduspider' => 'Baidu Spider',
		'Feedfetcher-Google' =>	'Feedfetcher-Google',
		'GameSpyHTTP' => 'GameSpy HTTP',
		'GigaBlast' => 'GigaBlast',
		'Gigabot' => 'Gigabot',
		'Accoona' => 'Google.com',
		'Googlebot-Image' => 'Googlebot-Image',
		'Googlebot' => 'Googlebot',
		'grub-client' => 'Grub',
		'gsa-crawler' => 'Google Search Appliance',
		'Slurp' => 'Inktomi Spider',
		'slurp@inktomi' => 'Hot Bot',
		
		'lycos' => 'Lycos.com',
		'whatuseek'	=> 'What You Seek',
		'ia_archiver' => 'Alexa',
		'is_archiver' => 'Archive.org',
		'archive_org' => 'Archive.org',
		
		'YandexBlog' => 'YandexBlog',
		'YandexSomething' => 'YandexSomething',
		'Yandex' => 'Yandex',
		'StackRambler' => 'Rambler',
		
		'WebAlta Crawler' => 'WebAlta Crawler',
		
		'Yahoo' => 'Yahoo',
		'zyborg@looksmart' => 'WiseNut',
		'WebCrawler' => 'Fast',
		'Openbot' => 'Openfind',
		'TurtleScanner' => 'Turtle',
		'libwww' => 'Punto',
		
		'msnbot' => 'MSN',
		'MnoGoSearch' => 'mnoGoSearch',
		'booch' => 'booch_Bot',
		'WebZIP' => 'WebZIP',
		'GetSmart' => 'GetSmart',
		'NaverBot' => 'NaverBot',
		'Vampire' => 'Net_Vampire',
		'ZipppBot' => 'ZipppBot',
		
		'W3C_Validator' => 'W3C Validator',
		'W3C_CSS_Validator' => 'W3C CSS Validator',
		
	];